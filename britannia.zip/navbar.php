<div class="row m-0 a-nav-back p-0 border-0 ">
            <div class="col-2 a-middle  ml-5">
                <a href="#" class="a-logo-href"><img src="img/bnf-logo.png" class="logo"></a>
            </div>
            <div class="col-10 m-0 p-0">
<nav>
                <ul class="navbar-nav flex-row justify-content-end socialmedia">
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia"><i class="fa-brands fa-x-twitter"></i></a>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia"><i class="fa-brands fa-youtube"></i></a>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia"><i class="fa-brands fa-linkedin"></i></a>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia"><i class="fa-brands fa-instagram"></i></a>
                    </li>
                </ul>
</nav>
<nav class="mb-3 navbar navbar-expand-lg bg-body-tertiary  m-0 p-0">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="a-nav nav-item dropdown">
                      <a class="a-href nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        WHO WE ARE
                      </a>
                        <ul class="dropdown-menu pull-right">
                            <li><a class="dropdown-item" href="#">Origin</a></li>
                            <li><a class="dropdown-item" href="#">Approach</a></li>
                            <li><a class="dropdown-item" href="#">Program(MRP + INP)</a></li>
                            <li><a class="dropdown-item" href="#">Irom Biscuit</a></li>
                            <li><a class="dropdown-item" href="#">Our Board</a></li>
                         </ul>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia">OUR REACH</a>
                    </li>
                    <li class="a-nav nav-item dropdown">
                      <a class="a-href nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        WHAT WE DO
                      </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">Intervention</a></li>
                            <li><a class="dropdown-item" href="#">Flagship Initiative</a></li>
                            <li><a class="dropdown-item" href="#">Suposhan Sakhi</a></li>
                            <li><a class="dropdown-item" href="#">Nutrition Champion</a></li>
                         </ul>
                    </li>
                    <li class="a-nav nav-item dropdown">
                      <a class="a-href nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        OUR IMPACT
                      </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">Malnutrition Anaemia Reduction Number</a></li>
                            <li><a class="dropdown-item" href="#">Case Story Link</a></li>
                         </ul>
                    </li>
                    <li class="a-nav nav-item dropdown">
                      <a class="a-href nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        PUBLICATIONS & MEDIA
                      </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">Anual Report</a></li>
                            <li><a class="dropdown-item" href="#">Flip Book</a></li>
                            <li><a class="dropdown-item" href="#">Brochure</a></li>
                         </ul>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia">EMPLOYEE ENGAGEMENT</a>
                    </li>
                    <li class="a-nav">
                      <a class="a-href nav-link" href="#" aria-label="Britannia">CONTACT US</a>
                    </li>
                    <li class="a-nav nav-item dropdown">
                      <a class="a-href nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        CALCULATOR
                      </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">HB Calculator</a></li>
                            <li><a class="dropdown-item" href="#">SAM/MAM(0-5 Child)</a></li>
                            <li><a class="dropdown-item" href="#">UW(0-5 Child)</a></li>
                            <li><a class="dropdown-item" href="#">BMI(5.1-19)</a></li>
                            <li><a class="dropdown-item" href="#">BMI For Audlts(19.1-Above)</a></li>
                         </ul>
                    </li>
                </ul>
    </div>
</nav>
            </div>
        </div>